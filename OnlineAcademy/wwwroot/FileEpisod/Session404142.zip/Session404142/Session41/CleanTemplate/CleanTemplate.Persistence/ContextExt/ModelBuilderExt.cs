﻿using CleanTemplate.Persistence.Config.ProductAgg;
using Microsoft.EntityFrameworkCore;

namespace CleanTemplate.Persistence.ContextExt
{
    internal static class ModelBuilderExt
    {
        public static void ConfigModels(this ModelBuilder builder)
        {
            builder.ApplyConfiguration(new ProductConfig());
        }
    }
}
