﻿namespace CleanTemplate.Application.ProductBiz
{
    public interface IProductService
    {
        void Execute();

        void Execute2(ProductViewModel product);
    }
}