﻿using CleanTemplate.Application.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanTemplate.Application.ProductBiz
{
    public class ProductService : IProductService
    {

        private readonly IMyContext _context;

        public ProductService(IMyContext context)
        {
            _context = context;
        }

        public void Execute()
        {
            _context.Products.Add(new Domain.ProductAgg.Product
            {
                TitleEn = "laptop asus",
                TitleFa = "لپ تاپ ایسوس",
                Note = "بسیار عالی",
                Date = new DateTime(2000, 1, 1)
            });

            _context.SaveChanges();
        }

        public void Execute2(ProductViewModel product)
        {
            _context.Products.Add(new Domain.ProductAgg.Product
            {
                TitleEn = product.TitleEn,
                TitleFa = product.TitleFa,
                Note = product.Note,
                Date = DateTime.Today
            });
            _context.SaveChanges();
        }
    }
}
