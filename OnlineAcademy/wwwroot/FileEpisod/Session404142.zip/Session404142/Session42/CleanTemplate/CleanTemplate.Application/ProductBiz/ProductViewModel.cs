﻿using System.ComponentModel.DataAnnotations;

namespace CleanTemplate.Application.ProductBiz
{
    // DTO vs ViewModel

    public class ProductViewModel
    {
        [Required(ErrorMessage = "Plz Enter {0}")]
        [Display(Name ="عنوان فارسی")]
        public string TitleFa { get; set; }

        [Required(ErrorMessage = "Plz Enter {0}")]
        [Display(Name = "عنوان خارجی")]
        public string TitleEn { get; set; }

        public string Note { get; set; }
    }
}