﻿using CleanTemplate.Domain.ProductAgg;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanTemplate.Application.Contracts
{
    public interface IMyContext
    {
        DbSet<Product> Products { get; set; }

        int SaveChanges();
    }
}
