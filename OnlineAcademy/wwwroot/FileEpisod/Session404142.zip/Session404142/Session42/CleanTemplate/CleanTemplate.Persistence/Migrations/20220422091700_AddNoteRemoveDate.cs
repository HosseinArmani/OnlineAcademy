﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CleanTemplate.Persistence.Migrations
{
    public partial class AddNoteRemoveDate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
