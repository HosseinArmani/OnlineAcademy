﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CleanTemplate.Persistence.Migrations
{
    public partial class AddTitleToProduct : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Title",
                table: "Products",
                newName: "TitleFa");

            migrationBuilder.AddColumn<string>(
                name: "TitleEn",
                table: "Products",
                type: "varchar(50)",
                unicode: false,
                maxLength: 50,
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TitleEn",
                table: "Products");

            migrationBuilder.RenameColumn(
                name: "TitleFa",
                table: "Products",
                newName: "Title");
        }
    }
}
