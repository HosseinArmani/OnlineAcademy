﻿using CleanTemplate.Domain.ProductAgg;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CleanTemplate.Persistence.Config.ProductAgg
{
    internal class ProductConfig : IEntityTypeConfiguration<Product>
    {
        public void Configure(EntityTypeBuilder<Product> builder)
        {
            builder.Property(p => p.TitleEn).HasMaxLength(50).IsUnicode(false).IsRequired();
            builder.Property(p => p.TitleFa).HasMaxLength(50).IsUnicode().IsRequired();
            
            builder.Property(p => p.Note).HasMaxLength(550).IsUnicode();

            builder.Property(p => p.Date).HasColumnType("date").IsRequired();


        }
    }
}
