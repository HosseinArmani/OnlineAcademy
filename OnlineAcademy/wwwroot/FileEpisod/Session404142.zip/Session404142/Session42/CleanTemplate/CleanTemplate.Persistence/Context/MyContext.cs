﻿using CleanTemplate.Domain.ProductAgg;
using Microsoft.EntityFrameworkCore;
using CleanTemplate.Persistence.ContextExt;
using CleanTemplate.Application.Contracts;

namespace CleanTemplate.Persistence.Context
{
    //onion-vs-clean-vs-hexagonal-architecture

    public class MyContext : DbContext , IMyContext
    {
        public MyContext()
        {

        }

        public DbSet<Product> Products { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ConfigModels();
            base.OnModelCreating(modelBuilder);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=Clean41 ; integrated security = true");
            base.OnConfiguring(optionsBuilder);
        }
    }
}
