﻿using CleanTemplate.Application.ProductBiz;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CleanTemplate.EndPoint.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }


        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create()
        {
            _productService.Execute();

            return Ok();
        }


        public IActionResult Create2()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create2(ProductViewModel product)
        {

            if (!ModelState.IsValid)
            {
                return View(product);
            }

            _productService.Execute2(product);

            return View();
        }
    }
}
