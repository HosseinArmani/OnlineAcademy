﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace EqualityExample
{
    class Person
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public DateTime BirthDate { get; set; }

        public class EqualByID : IEqualityComparer<Person>
        {
            public bool Equals(Person x, Person y)
            {
                return x.ID == y.ID;
            }

            public int GetHashCode([DisallowNull] Person obj)
            {
                return obj.ID.GetHashCode();
            }
        }


        public class EqualByFullName : IEqualityComparer<Person>
        {
            public bool Equals(Person x, Person y)
            {
                return x.FirstName == y.FirstName &&
                       x.LastName == y.LastName;
            }

            public int GetHashCode([DisallowNull] Person obj)
            {
                var fullName = obj.FirstName + obj.LastName;

                //return fullName.ToLower().GetHashCode();
                return fullName.GetHashCode();

            }
        }


        public class EqualByFullName2 : IEqualityComparer<Person>
        {
            public bool Equals(Person x, Person y)
            {

                var isEqual = x.FirstName.Equals(y.FirstName, StringComparison.OrdinalIgnoreCase) &&
                             x.LastName.Equals(y.LastName, StringComparison.OrdinalIgnoreCase);

                return isEqual;
            }

            public int GetHashCode([DisallowNull] Person obj)
            {
                var fullName = obj.FirstName + obj.LastName;
                return fullName.ToLower().GetHashCode();


            }
        }


        //Extension methods must be defined in a top level static class;
        //LocalExt is a nested class
        public static class LocalExt
        {
           // public static void F1(this Person person){ }
        }
    
    


    }
}
