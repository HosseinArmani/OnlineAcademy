﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EqualityExample
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");


            var people = new List<Person>
            {
                new Person
                {
                    ID = 1 ,
                    FirstName = "AAA" ,
                    LastName = "BBB" ,
                    BirthDate = new DateTime(2001,1,1)
                },
                new Person
                {
                    ID = 2 ,
                    FirstName = "AAa" ,
                    LastName = "BBB" ,
                    BirthDate = new DateTime(2002,1,1)
                },
                new Person
                {
                    ID = 3 ,
                    FirstName = "AAA" ,
                    LastName = "BBb" ,
                    BirthDate = new DateTime(2003,1,1)
                },
                new Person
                {
                    ID = 4 ,
                    FirstName = "AAA3" ,
                    LastName = "BBB3" ,
                    BirthDate = new DateTime(2003,1,1)
                }
            };


            var uniquePeople1 = people.Distinct().ToList();

            var uniquePeople2 = people.Distinct(new Person.EqualByID()).ToList();

            var uniquePeople3 = people.Distinct(new Person.EqualByFullName2()).ToList();


            Console.WriteLine("soroushsadr".GetHashCode());
            Console.WriteLine("SoroushSadr".GetHashCode());
            Console.WriteLine("soroushsadr".GetHashCode());


            Console.WriteLine("AAA".Equals("aaa"));
            Console.WriteLine("AAA".Equals("aaa", StringComparison.OrdinalIgnoreCase));
            Console.WriteLine("AAA".Equals("aaa", StringComparison.CurrentCultureIgnoreCase));
            Console.WriteLine("AAA".Equals("aaa", StringComparison.InvariantCultureIgnoreCase));


            var s1 = "AAA";
            var s2 = "aaa";

            Console.WriteLine(s1.Equals(s2));
            Console.WriteLine(s1.Equals(s2, StringComparison.OrdinalIgnoreCase));

            Console.WriteLine(s1 == s2);
            Console.WriteLine(s1.ToLower() == s2.ToLower());

            Console.Clear();

            var numbers1 = new int[1, 2, 3];
            var numbers2 = new int[1, 2, 3];


            Console.WriteLine(numbers1 == numbers2);
            Console.WriteLine(numbers1.Equals(numbers2));


            var numbers3 = numbers1;
            Console.WriteLine(numbers1 == numbers3);
            Console.WriteLine(numbers1.Equals(numbers3));

            Console.Clear();

            var c1 = new Car
            {
                Title = "AAA1",
                ID = 100
            };

            var c2 = new Car
            {
                Title = "AAA1",
                ID = 100
            };


            Console.WriteLine(c1 == c2);
            Console.WriteLine(c1.Equals(c2));
            Console.WriteLine(object.Equals(c1, c2));

            //c1 = c2;

            Console.WriteLine(c1 == c2);
            Console.WriteLine(c1.Equals(c2));
            Console.WriteLine(object.Equals(c1, c2));

            Console.WriteLine(c1.Title);
            Console.WriteLine(c2.Title);
            Console.WriteLine(c1.Title == c2.Title);

            var person = new Person
            {
                ID = 1,
                FirstName = "AAA",
                LastName = "BBB",
                BirthDate = DateTime.Now
            };
           
            var a1 = "soroush";
            person.FirstName = a1;

            Console.WriteLine(a1);
            Console.WriteLine(person.FirstName);


            var b1 = a1;
            Console.WriteLine(b1);

            b1 = "new name";

            Console.WriteLine(a1);
            Console.WriteLine(person.FirstName);
            Console.WriteLine(b1);

            Console.Clear();

            var person2 = new Person
            {
                ID = 1,
                FirstName = "AAA2",
                LastName = "BBB",
                BirthDate = DateTime.Now
            };


            person2.FirstName = person.FirstName;

            Console.WriteLine(person.FirstName);
            Console.WriteLine(person2.FirstName);

            person.FirstName = "new person";

            Console.WriteLine(person.FirstName);
            Console.WriteLine(person2.FirstName);



        }
    }
}
