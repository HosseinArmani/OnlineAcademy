﻿namespace EqualityExample
{
    public partial class Car
    {
        public string Title { get; set; }
        public int ID { get; set; }

        public static bool operator ==(Car car1, Car car2)
        {
            return car1.ID == car2.ID &&
                   car1.Title == car2.Title;
        }

        public static bool operator !=(Car car1, Car car2)
        {
            return car1.ID != car2.ID ||
                   car1.Title != car2.Title;
        }

        public override bool Equals(object obj)
        {
            return (this.ID == (obj as Car).ID && this.Title == (obj as Car).Title);
        }

        public override int GetHashCode()
        {
            return (this.ID + this.Title).GetHashCode();
        }
    }
}
