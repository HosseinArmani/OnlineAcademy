﻿using EqualityExample;

namespace PartialTestExample
{
    public partial class Car
    {
        public string Title { get; set; }
        public int ID { get; set; }
    }
}
