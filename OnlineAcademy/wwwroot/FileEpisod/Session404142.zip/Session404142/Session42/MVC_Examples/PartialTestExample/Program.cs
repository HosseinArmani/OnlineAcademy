﻿using System;
using EqualityExample;

namespace PartialTestExample
{

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            var c1 = new PartialTestExample.Car();

            var c2 = new EqualityExample.Car();

            var c3 = new Car();

        }
    }
}
