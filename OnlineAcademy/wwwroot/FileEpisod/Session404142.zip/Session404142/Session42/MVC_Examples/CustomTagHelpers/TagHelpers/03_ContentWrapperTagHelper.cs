﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Linq;

namespace CustomTagHelper.TagHelpers
{
    [HtmlTargetElement("div", Attributes = "title")]
    public class ContentWrapperTagHelper : TagHelper
    {
        /// <summary>
        /// آیا در هدر نمایش داده شود
        /// </summary>
        public bool IncludeHeader { get; set; } = true;
        /// <summary>
        /// آیا در فوتر نمایش میشود
        /// </summary>
        public bool IncludeFooter { get; set; } = true;
      
        /// <summary>
        /// عنوان
        /// </summary>
        public string Title { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.Attributes.SetAttribute("class", "m-1 p-1");

            TagBuilder title = new("h1");
            title.InnerHtml.Append(Title);

            TagBuilder container = new("div");
            container.Attributes["class"] = "bg-info m-1 p-1";

            container.InnerHtml.AppendHtml(title);

            if (IncludeHeader)
            {
                output.PreElement.SetHtmlContent(container);
            }

            if (IncludeFooter)
            {
                output.PostElement.SetHtmlContent(container);
            }
        }
    }

}
