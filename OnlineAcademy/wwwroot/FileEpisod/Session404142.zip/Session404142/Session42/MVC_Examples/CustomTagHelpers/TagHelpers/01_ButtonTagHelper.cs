﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CustomTagHelper.TagHelpers
{
    
    ///// <summary>
    ///// بر اساس قرارداد نام گذاری به باتن ها اعمال میشود
    ///// </summary>
    //public class ButtonTagHelper : TagHelper
    //{
    //    /// <summary>
    //    /// رنگ های استاندارد بوت استرپ
    //    /// </summary>
    //    public string BsButtonColor { get; set; }

    //    public override void Process(TagHelperContext context, TagHelperOutput output)
    //    {
    //        output.Attributes.SetAttribute("class", $"btn btn-{BsButtonColor}");
    //    }
    //}

    

    /*
    /// <summary>
    /// بر اساس قرارداد نام گذاری به باتن ها اعمال میشود
    /// </summary>
    public class ButtonTagHelper : TagHelper
    {
        /// <summary>
        /// رنگ های استاندارد بوت استرپ
        /// </summary>
        public string BsButtonColor { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            if (string.IsNullOrEmpty(BsButtonColor))
            {
                BsButtonColor = "info";
            }         
            output.Attributes.SetAttribute("class", $"btn btn-{BsButtonColor}");
        }
    }
    */
    

    /*
    [HtmlTargetElement("button", Attributes = "bs-button-color", ParentTag = "form")]
    public class ButtonTagHelper : TagHelper
    {
        /// <summary>
        /// رنگ های استاندارد بوت استرپ
        /// </summary>
        public string BsButtonColor { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.Attributes.SetAttribute("class", $"btn btn-{BsButtonColor}");
        }
    }

*/

    /*
    [HtmlTargetElement("button", Attributes = "bs-button-color")]
    public class ButtonTagHelper : TagHelper
    {
        /// <summary>
        /// رنگ های استاندارد بوت استرپ
        /// </summary>
        public string BsButtonColor { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.Attributes.SetAttribute("class", $"btn btn-{BsButtonColor}");
        }
    }
    */


    /*
    [HtmlTargetElement("button", Attributes = "bs-button-color", ParentTag = "form")]
    [HtmlTargetElement("button", Attributes = "bs-button-color")]
    [HtmlTargetElement("a", Attributes = "bs-button-color")]
    public class ButtonTagHelper : TagHelper
    {
        /// <summary>
        /// رنگ های استاندارد بوت استرپ
        /// </summary>
        public string BsButtonColor { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.Attributes.SetAttribute("class", $"btn btn-{BsButtonColor}");
        }
    }
   */


    
    [HtmlTargetElement("button", Attributes = "bs-button-color", ParentTag = "form")]
    [HtmlTargetElement("button", Attributes = "bs-button-color")]
    [HtmlTargetElement("a", Attributes = "bs-button-color")]
    [HtmlTargetElement("button", Attributes = "[type=reset]")]
    public class ButtonTagHelper : TagHelper
    {
        /// <summary>
        /// رنگ های استاندارد بوت استرپ
        /// </summary>
        public string BsButtonColor { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            var type = output.Attributes["type"]?.Value.ToString().ToLower();

            if (type == "reset")
            {
                BsButtonColor = "warning";
            }

            output.Attributes.SetAttribute("class", $"btn btn-{BsButtonColor}");
        }
    }
    

}
