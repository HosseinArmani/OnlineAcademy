﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Part01
{
    public partial class Product
    {
        public Product()
        {
            OrderDetails = new HashSet<OrderDetail>();
            Prices = new HashSet<Price>();
        }

        public int Id { get; set; }
        public string Title { get; set; }

        public virtual ICollection<OrderDetail> OrderDetails { get; set; }
        public virtual ICollection<Price> Prices { get; set; }
    }
}
