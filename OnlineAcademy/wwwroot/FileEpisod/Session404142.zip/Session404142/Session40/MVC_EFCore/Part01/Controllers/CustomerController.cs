﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Part01.Controllers
{
    public class CustomerController : Controller
    {
        public IActionResult Index()
        {
            var db = new SimpleShop2Context();
            var customers = db.Customers.ToList();
            return View(customers);
        }        
    }
}
