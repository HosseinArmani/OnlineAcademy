﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Part02_Model.Migrations
{
    public partial class AddData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                schema: "SHOPPING",
                table: "Customer",
                columns: new[] { "ID", "FullName" },
                values: new object[] { 1, "سروش صدر" });

            migrationBuilder.InsertData(
                schema: "SHOPPING",
                table: "Customer",
                columns: new[] { "ID", "FullName" },
                values: new object[] { 2, "علی صدر" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "SHOPPING",
                table: "Customer",
                keyColumn: "ID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                schema: "SHOPPING",
                table: "Customer",
                keyColumn: "ID",
                keyValue: 2);
        }
    }
}
