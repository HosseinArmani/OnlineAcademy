﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Part02_Model.SimpleShopModel
{
    [Table("PRICE", Schema = "SHOPPING")]
    public partial class Price
    {
        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Column("ProductID")]
        public int ProductId { get; set; }
        public int Amount { get; set; }

        [ForeignKey(nameof(ProductId))]
        [InverseProperty("Prices")]
        public virtual Product Product { get; set; }
    }
}
