﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Part02_Model.SimpleShopModel
{
    [Table("PRODUCT", Schema = "SHOPPING")]
    public partial class Product
    {
        public Product()
        {
            OrderDetails = new HashSet<OrderDetail>();
            Prices = new HashSet<Price>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Title { get; set; }

        public int? Rate { get; set; }

        public string Note { get; set; }

        public DateTime? ExpireDate { get; set; }

        [InverseProperty(nameof(OrderDetail.Product))]
        public virtual ICollection<OrderDetail> OrderDetails { get; set; }
        [InverseProperty(nameof(Price.Product))]
        public virtual ICollection<Price> Prices { get; set; }
    }
}
